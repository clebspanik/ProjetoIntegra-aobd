package com.example.demo.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name= "Vendas", uniqueConstraints= {@UniqueConstraint(columnNames= {"idvenda"})})
public class Vendas {
	
	@Id
	@Column (name = "id")
	@GeneratedValue
	public Long id;
	@ManyToOne
	private Produtos produtos;
	private String descricao_produto;
	@ManyToOne
	private Pessoas pessoas;
	private String nome_pessoa;
	@Column (name = "quantidade")
	private int quantidade;
	@Column (name = "total")
	private double total;
	
	public Produtos getProduto () {
		return produtos;
	}
	
	public void setProduto (Produtos produtos) {
		this.produtos = produtos;
	}
	
	public Pessoas getCliente() {
		return pessoas;
	}
	
	public void setCliente (Pessoas pessoas) {
		this.pessoas = pessoas;
	}
	
	public int getQuantidade() {
		return quantidade;
	}
	
	public void setQuantindade (int quantidade) {
		this.quantidade = quantidade;
	}
	
	public double getTotal() {
		return total = quantidade * produtos.getVlrVenda();
	}
	public String getNome_produto() {
		return descricao_produto = produtos.getDescricao();
	}
	public String getNome_Pessoas () {
		return nome_pessoa = pessoas.getNome();
	}
	
}
	