package com.example.demo.adm;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import jakarta.transaction.Transactional;

public class UserDetailsServiceImpl implements UserDetailsService {
	@Autowired
	private UsuarioRepositorio usuariorepositorio;
	
	@Override
	@Transactional
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException{
		Usuario usuario = usuariorepositorio.findByUsername(username);
		Set<GrantedAuthority>autoroties = new HashSet<>();
		autoroties.add(new SimpleGrantedAuthority(usuario.getRole()));
		User userSpring = new User(usuario.getUsername(), usuario.getPassword(), autoroties);
		return userSpring;
	}
	
	
}
